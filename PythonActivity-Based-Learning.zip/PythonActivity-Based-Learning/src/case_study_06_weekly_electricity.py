# Case Study 6: Weekly Electricity Consumption Matrix
appliances = ["AC Unit", "Refrigerator", "Water Heater", "Washing Mach", "Lighting"]
days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
daily_limit = 25.0
appliance_limit = 45.0

# Nested list: [appliance][day] readings in kWh
readings = [
    [9.5, 10.2, 8.8, 11.0, 10.5, 13.4, 12.6],
    [3.2, 3.1, 3.3, 3.2, 3.1, 3.4, 3.3],
    [5.0, 4.8, 5.2, 5.5, 5.1, 6.2, 6.0],
    [2.4, 0.0, 2.6, 0.0, 2.5, 3.8, 3.2],
    [3.5, 3.4, 3.6, 3.8, 3.7, 4.2, 4.1]
]

print("=" * 68)
print("          WEEKLY ELECTRICITY CONSUMPTION MATRIX REPORT")
print("=" * 68)

# 1. Appliance-wise weekly totals
print("\n1. Appliance-Wise Weekly Consumption (Limit: " + str(appliance_limit) + " kWh):")
exceeded_appliances = []
grand_total = 0.0

for a in range(len(appliances)):
    app_sum = 0.0
    for d in range(len(days)):
        app_sum = app_sum + readings[a][d]
    grand_total = grand_total + app_sum
    flag = "  [EXCEEDS LIMIT]" if app_sum > appliance_limit else ""
    if app_sum > appliance_limit:
        exceeded_appliances.append((appliances[a], round(app_sum, 2)))
    print("   " + appliances[a].ljust(14) + " : " + str(round(app_sum, 2)).rjust(6) + " kWh" + flag)

# 2. Daily totals across all appliances
print("\n2. Daily Consumption Totals & Pattern (Limit: " + str(daily_limit) + " kWh):")
exceeded_days = []

for d in range(len(days)):
    day_sum = 0.0
    for a in range(len(appliances)):
        day_sum = day_sum + readings[a][d]
    bar = "#" * int(day_sum)
    flag = " [OVER LIMIT]" if day_sum > daily_limit else ""
    if day_sum > daily_limit:
        exceeded_days.append((days[d], round(day_sum, 2)))
    print("   " + days[d] + " : " + str(round(day_sum, 2)).rjust(5) + " kWh | " + bar + flag)

print("\n3. Threshold Breach Summary:")
print("   Grand Weekly Total : " + str(round(grand_total, 2)) + " kWh (Daily Avg: " + str(round(grand_total / 7, 2)) + " kWh)")
print("   Appliances Over Limit: " + str(len(exceeded_appliances)) + " -> " + str(exceeded_appliances))
print("   Days Over Limit      : " + str(len(exceeded_days)) + " -> " + str(exceeded_days))
print("=" * 68)
