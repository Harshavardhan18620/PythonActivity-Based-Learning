# Case Study 2: Nested List Classroom Occupancy Analysis
room_names = ["Room 101", "Room 102", "Room 103"]

# 3D nested list: [room][row][col]; "RES" = reserved, "" = vacant
classrooms = [
    [["RES", "", ""], ["", "", "RES"]],
    [["", "RES", ""], ["", "", ""]],
    [["RES", "", "RES"], ["", "", ""]]
]

# Tuple-based allocation requests: (student_id, room_index, row, col)
requests = [
    ("S101", 0, 0, 1),
    ("S102", 0, 0, 0),   # Attempts reserved seat
    ("S103", 0, 1, 0),
    ("S101", 1, 0, 0),   # Duplicate student assignment
    ("S104", 1, 0, 0),
    ("S105", 1, 1, 2),
    ("S106", 2, 0, 1),
    ("S107", 2, 1, 1),
    ("S108", 0, 0, 1)    # Seat already occupied
]

assigned_students = []
rejected_log = []

print("=" * 66)
print("         CLASSROOM OCCUPANCY & SEAT ALLOCATION REPORT")
print("=" * 66)
print("\n1. Allocation Processing Log:")

for req in requests:
    student_id, r_idx, row, col = req

    # Check duplicate student across all rooms
    is_duplicate = False
    for sid in assigned_students:
        if sid == student_id:
            is_duplicate = True
            break

    if is_duplicate:
        msg = student_id + " -> REJECTED (Duplicate student assignment)"
        rejected_log.append(msg)
        print("   [!] " + msg)
    elif classrooms[r_idx][row][col] == "RES":
        msg = student_id + " -> REJECTED (Seat " + room_names[r_idx] + "[" + str(row) + "][" + str(col) + "] is RESERVED)"
        rejected_log.append(msg)
        print("   [!] " + msg)
    elif classrooms[r_idx][row][col] != "":
        msg = student_id + " -> REJECTED (Seat " + room_names[r_idx] + "[" + str(row) + "][" + str(col) + "] already OCCUPIED)"
        rejected_log.append(msg)
        print("   [!] " + msg)
    else:
        classrooms[r_idx][row][col] = student_id
        assigned_students.append(student_id)
        print("   [OK] " + student_id + " -> Assigned to " + room_names[r_idx] + " Row " + str(row) + ", Col " + str(col))

# 2. Seating grid pattern & capacity summary
print("\n2. Classroom Seating Maps & Capacity Summary:")
total_seats_all = 0
total_occ_all = 0
total_res_all = 0
total_vac_all = 0

for r_idx in range(len(classrooms)):
    occ = 0
    res = 0
    vac = 0
    print("\n   " + room_names[r_idx] + ":")
    for row in range(len(classrooms[r_idx])):
        line = "     "
        for col in range(len(classrooms[r_idx][row])):
            seat = classrooms[r_idx][row][col]
            if seat == "RES":
                res = res + 1
                line = line + "[ RES  ] "
            elif seat == "":
                vac = vac + 1
                line = line + "[ FREE ] "
            else:
                occ = occ + 1
                line = line + "[ " + seat + " ] "
        print(line)
    room_total = occ + res + vac
    total_seats_all = total_seats_all + room_total
    total_occ_all = total_occ_all + occ
    total_res_all = total_res_all + res
    total_vac_all = total_vac_all + vac
    print("     Summary -> Total: " + str(room_total) + " | Occupied: " + str(occ) + " | Reserved: " + str(res) + " | Vacant: " + str(vac))

print("\n3. Overall Totals:")
print("   Total Seats: " + str(total_seats_all) + " | Occupied: " + str(total_occ_all) + " | Reserved: " + str(total_res_all) + " | Vacant: " + str(total_vac_all))
print("   Total Rejected Requests: " + str(len(rejected_log)))
print("=" * 66)
