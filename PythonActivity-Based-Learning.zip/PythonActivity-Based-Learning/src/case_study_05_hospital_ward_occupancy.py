# Case Study 5: Hospital Ward Occupancy Monitoring
wards = ["ICU", "General", "Pediatrics", "Maternity"]
capacities = [20, 60, 30, 25]
days = ["Mon", "Tue", "Wed", "Thu", "Fri"]

# Nested list: [ward][day] occupied bed counts
occupancy = [
    [18, 21, 19, 22, 20],
    [48, 55, 52, 63, 58],
    [22, 25, 28, 26, 24],
    [19, 21, 24, 26, 22]
]

print("=" * 68)
print("             HOSPITAL WARD OCCUPANCY MONITORING REPORT")
print("=" * 68)

violations = []
daily_totals = [0, 0, 0, 0, 0]

print("\n1. Ward-Wise Daily Utilization (%) & Violations:")
for w in range(len(wards)):
    cap = capacities[w]
    ward_sum = 0
    print("\n   Ward: " + wards[w] + " (Bed Capacity: " + str(cap) + ")")
    for d in range(len(days)):
        occ = occupancy[w][d]
        daily_totals[d] = daily_totals[d] + occ
        ward_sum = ward_sum + occ
        util = (occ / cap) * 100
        status = "NORMAL"
        if occ > cap:
            status = "VIOLATION (+" + str(occ - cap) + " beds)"
            violations.append((wards[w], days[d], occ, cap, round(util, 1)))
        elif util >= 90:
            status = "HIGH ALERT"
        print("     " + days[d] + " : " + str(occ).rjust(2) + "/" + str(cap).ljust(2) + " (" + str(round(util, 1)).rjust(5) + "%) -> " + status)
    avg_util = (ward_sum / (cap * len(days))) * 100
    meter = "#" * int(avg_util // 5)
    print("     5-Day Avg Utilization: " + str(round(avg_util, 1)) + "% [" + meter.ljust(20) + "]")

# 2. Identify peak-demand period
peak_day_idx = 0
for d in range(1, len(days)):
    if daily_totals[d] > daily_totals[peak_day_idx]:
        peak_day_idx = d

print("\n2. Daily Hospital-Wide Bed Demand:")
for d in range(len(days)):
    tag = "  <-- PEAK DEMAND" if d == peak_day_idx else ""
    print("   " + days[d] + " : " + str(daily_totals[d]).rjust(3) + " beds occupied" + tag)

print("\n3. Capacity Violations Detected (" + str(len(violations)) + "):")
for v in violations:
    w_name, day_name, occ_val, cap_val, util_val = v
    print("   - " + w_name + " on " + day_name + ": " + str(occ_val) + "/" + str(cap_val) + " (" + str(util_val) + "%)")
print("=" * 68)
