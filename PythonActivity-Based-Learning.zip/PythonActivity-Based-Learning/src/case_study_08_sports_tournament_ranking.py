# Case Study 8: Sports Tournament Ranking System
teams = ["Falcons", "Titans", "Strikers", "Warriors"]

# Match results as list of tuples: (team_a, team_b, goals_a, goals_b)
matches = [
    ("Falcons", "Titans", 2, 1),
    ("Strikers", "Warriors", 1, 1),
    ("Falcons", "Strikers", 0, 2),
    ("Titans", "Warriors", 3, 0),
    ("Falcons", "Warriors", 2, 0),
    ("Titans", "Strikers", 1, 1)
]

# Policy: Win = 3 pts, Draw = 1 pt, Loss = 0 pts
# Tie-breakers: 1) Points desc, 2) Goal Difference (GD) desc, 3) Goals For (GF) desc
# Stats table per team: [name, played, won, drawn, lost, gf, ga, gd, pts]
standings = []
for t in teams:
    standings.append([t, 0, 0, 0, 0, 0, 0, 0, 0])

for match in matches:
    t_a, t_b, g_a, g_b = match
    idx_a = teams.index(t_a)
    idx_b = teams.index(t_b)

    standings[idx_a][1] = standings[idx_a][1] + 1
    standings[idx_b][1] = standings[idx_b][1] + 1
    standings[idx_a][5] = standings[idx_a][5] + g_a
    standings[idx_a][6] = standings[idx_a][6] + g_b
    standings[idx_b][5] = standings[idx_b][5] + g_b
    standings[idx_b][6] = standings[idx_b][6] + g_a

    if g_a > g_b:
        standings[idx_a][2] = standings[idx_a][2] + 1
        standings[idx_a][8] = standings[idx_a][8] + 3
        standings[idx_b][4] = standings[idx_b][4] + 1
    elif g_b > g_a:
        standings[idx_b][2] = standings[idx_b][2] + 1
        standings[idx_b][8] = standings[idx_b][8] + 3
        standings[idx_a][4] = standings[idx_a][4] + 1
    else:
        standings[idx_a][3] = standings[idx_a][3] + 1
        standings[idx_b][3] = standings[idx_b][3] + 1
        standings[idx_a][8] = standings[idx_a][8] + 1
        standings[idx_b][8] = standings[idx_b][8] + 1

for row in standings:
    row[7] = row[5] - row[6]

# Bubble sort using multi-key competition policy (Pts, GD, GF)
n = len(standings)
for i in range(n):
    for j in range(0, n - i - 1):
        a = standings[j]
        b = standings[j + 1]
        swap = False
        if b[8] > a[8]:
            swap = True
        elif b[8] == a[8] and b[7] > a[7]:
            swap = True
        elif b[8] == a[8] and b[7] == a[7] and b[5] > a[5]:
            swap = True
        if swap:
            standings[j], standings[j + 1] = standings[j + 1], standings[j]

print("=" * 68)
print("               SPORTS TOURNAMENT RANKING TABLE")
print("=" * 68)
print(" Rank | Team      | P | W | D | L | GF | GA |  GD | Pts | Form")
print(" " + "-" * 64)

for rank in range(len(standings)):
    name, p, w, d, l, gf, ga, gd, pts = standings[rank]
    gd_str = ("+" + str(gd)) if gd > 0 else str(gd)
    stars = "*" * pts
    print("  #" + str(rank + 1) + "  | " + name.ljust(9) + " | " + str(p) + " | " + str(w) + " | " + str(d) + " | " + str(l) + " | " + str(gf).rjust(2) + " | " + str(ga).rjust(2) + " | " + gd_str.rjust(3) + " | " + str(pts).rjust(3) + " | " + stars)

print("\n Champion: " + standings[0][0] + " (" + str(standings[0][8]) + " pts, GD " + str(standings[0][7]) + ")")
print("=" * 68)
