# Case Study 3: Student Marks Matrix Analysis
students = ["Ananya", "Bhavesh", "Charan", "Divya", "Eshan"]
subjects = ["Maths", "Physics", "Python", "English"]
low_avg_threshold = 65.0

# Nested list: rows = students, columns = subjects
marks = [
    [88, 76, 94, 82],
    [62, 54, 71, 68],
    [95, 84, 91, 86],
    [70, 58, 79, 75],
    [55, 49, 68, 64]
]

print("=" * 66)
print("              STUDENT MARKS MATRIX ANALYSIS REPORT")
print("=" * 66)

# 1. Row-wise statistics (per student)
print("\n1. Student-Wise Performance (Row Statistics):")
print("   Student    | Total |  Avg  | High | Low | Grade")
print("   " + "-" * 52)

top_total = -1
top_students = []

for i in range(len(students)):
    row_sum = 0
    row_max = marks[i][0]
    row_min = marks[i][0]
    for j in range(len(subjects)):
        val = marks[i][j]
        row_sum = row_sum + val
        if val > row_max:
            row_max = val
        if val < row_min:
            row_min = val
    avg = row_sum / len(subjects)
    if avg >= 85:
        grade = "A+"
    elif avg >= 75:
        grade = "A"
    elif avg >= 60:
        grade = "B"
    else:
        grade = "C"

    print("   " + students[i].ljust(10) + " | " + str(row_sum).rjust(5) + " | " + str(round(avg, 1)).rjust(5) + " | " + str(row_max).rjust(4) + " | " + str(row_min).rjust(3) + " | " + grade)

    if row_sum > top_total:
        top_total = row_sum
        top_students = [students[i]]
    elif row_sum == top_total:
        top_students.append(students[i])

print("\n   Top Performer(s): " + ", ".join(top_students) + " (Total: " + str(top_total) + " / 400)")

# 2. Column-wise statistics (per subject)
print("\n2. Subject-Wise Statistics & Average Bar Pattern:")
low_subjects = []

for j in range(len(subjects)):
    col_sum = 0
    col_max = marks[0][j]
    col_min = marks[0][j]
    for i in range(len(students)):
        val = marks[i][j]
        col_sum = col_sum + val
        if val > col_max:
            col_max = val
        if val < col_min:
            col_min = val
    col_avg = col_sum / len(students)
    stars = "*" * int(col_avg // 5)
    flag = " [LOW AVG]" if col_avg < low_avg_threshold else ""
    if col_avg < low_avg_threshold:
        low_subjects.append((subjects[j], round(col_avg, 2)))
    print("   " + subjects[j].ljust(8) + " | Avg: " + str(round(col_avg, 2)).rjust(5) + " | Max: " + str(col_max).rjust(2) + " | Min: " + str(col_min).rjust(2) + " | " + stars + flag)

print("\n3. Subjects Below Threshold (" + str(low_avg_threshold) + "):")
if len(low_subjects) == 0:
    print("   None")
else:
    for item in low_subjects:
        sub_name, sub_avg = item
        print("   - " + sub_name + " (Average: " + str(sub_avg) + ")")
print("=" * 66)
