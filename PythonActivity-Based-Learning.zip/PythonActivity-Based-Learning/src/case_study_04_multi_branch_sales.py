# Case Study 4: Multi-Branch Sales Matrix Comparison
branches = ["North Branch", "South Branch", "West Branch"]
products = ["Laptop", "Tablet", "Headset", "Monitor"]
days = ["Mon", "Tue", "Wed", "Thu", "Fri"]

# 3D nested list: [branch][product][day] (units sold)
sales = [
    [   # North Branch
        [12, 15, 14, 18, 21],
        [8, 10, 9, 11, 14],
        [25, 22, 30, 28, 35],
        [6, 9, 8, 10, 12]
    ],
    [   # South Branch
        [18, 20, 17, 22, 25],
        [14, 16, 15, 19, 20],
        [15, 18, 16, 20, 22],
        [10, 12, 11, 14, 15]
    ],
    [   # West Branch
        [10, 12, 11, 13, 16],
        [20, 24, 22, 26, 28],
        [14, 16, 15, 18, 20],
        [8, 7, 9, 11, 10]
    ]
]

print("=" * 66)
print("           MULTI-BRANCH SALES MATRIX COMPARISON REPORT")
print("=" * 66)

# 1. Product totals across all branches and days
print("\n1. Overall Product Totals (All Branches, 5 Days):")
product_totals = []
for p in range(len(products)):
    p_total = 0
    for b in range(len(branches)):
        for d in range(len(days)):
            p_total = p_total + sales[b][p][d]
    product_totals.append(p_total)
    print("   " + products[p].ljust(10) + " : " + str(p_total).rjust(4) + " units")

# 2. Branch totals and best-performing product per branch
print("\n2. Branch Comparison & Best-Performing Product:")
branch_totals = []
best_branch_idx = 0

for b in range(len(branches)):
    b_total = 0
    best_p_idx = 0
    best_p_val = -1
    for p in range(len(products)):
        bp_sum = 0
        for d in range(len(days)):
            bp_sum = bp_sum + sales[b][p][d]
        b_total = b_total + bp_sum
        if bp_sum > best_p_val:
            best_p_val = bp_sum
            best_p_idx = p
    branch_totals.append(b_total)
    if b_total > branch_totals[best_branch_idx]:
        best_branch_idx = b
    bar = "=" * (b_total // 20)
    print("   " + branches[b].ljust(13) + " | Total: " + str(b_total).rjust(3) + " | Best: " + products[best_p_idx].ljust(8) + " (" + str(best_p_val) + ") | " + bar)

print("\n3. Top Performing Branch:")
print("   " + branches[best_branch_idx] + " with " + str(branch_totals[best_branch_idx]) + " total units sold.")
print("=" * 66)
