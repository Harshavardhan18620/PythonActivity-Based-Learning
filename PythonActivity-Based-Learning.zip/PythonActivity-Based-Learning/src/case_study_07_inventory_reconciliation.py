# Case Study 7: Inventory Matrix Reconciliation
warehouses = ["WH-North", "WH-Central", "WH-South"]
products = ["Router", "Switch", "CableBox", "Modem"]

# Nested lists: [warehouse][product]
current_stock = [
    [120, 45, 210, 60],
    [70,  95, 140, 85],
    [95,  50, 160, 40]
]
target_stock = [
    [100, 60, 180, 70],
    [90,  70, 160, 70],
    [90,  60, 170, 60]
]

print("=" * 68)
print("              INVENTORY MATRIX RECONCILIATION REPORT")
print("=" * 68)

# 1. Calculate variance matrix (current - target)
variance = []
print("\n1. Warehouse Stock Variance (Current vs Target):")
for w in range(len(warehouses)):
    row_var = []
    line = "   " + warehouses[w].ljust(11) + " | "
    for p in range(len(products)):
        diff = current_stock[w][p] - target_stock[w][p]
        row_var.append(diff)
        sign = "+" if diff > 0 else ""
        line = line + products[p] + ":" + (sign + str(diff)).rjust(4) + "  "
    variance.append(row_var)
    print(line)

# 2. Identify shortages, surpluses, and compute required transfers
print("\n2. Recommended Inter-Warehouse Transfers:")
transfers = []
unresolved_shortages = []

for p in range(len(products)):
    # Copy variances for product p across warehouses
    surpluses = []
    shortages = []
    for w in range(len(warehouses)):
        if variance[w][p] > 0:
            surpluses.append([w, variance[w][p]])
        elif variance[w][p] < 0:
            shortages.append([w, -variance[w][p]])

    # Match surplus warehouses with shortage warehouses
    s_idx = 0
    d_idx = 0
    while s_idx < len(surpluses) and d_idx < len(shortages):
        from_w = surpluses[s_idx][0]
        avail = surpluses[s_idx][1]
        to_w = shortages[d_idx][0]
        need = shortages[d_idx][1]

        qty = avail if avail < need else need
        transfers.append((warehouses[from_w], warehouses[to_w], products[p], qty))
        surpluses[s_idx][1] = avail - qty
        shortages[d_idx][1] = need - qty

        if surpluses[s_idx][1] == 0:
            s_idx = s_idx + 1
        if shortages[d_idx][1] == 0:
            d_idx = d_idx + 1

    # Record any unmet shortage
    while d_idx < len(shortages):
        if shortages[d_idx][1] > 0:
            unresolved_shortages.append((warehouses[shortages[d_idx][0]], products[p], shortages[d_idx][1]))
        d_idx = d_idx + 1

for t in transfers:
    src, dst, prod, qty = t
    print("   Transfer " + str(qty).rjust(2) + " units of " + prod.ljust(8) + " : " + src + " -> " + dst)

print("\n3. Unresolved External Procurement Needed:")
if len(unresolved_shortages) == 0:
    print("   None (All targets met via internal transfers)")
else:
    for u in unresolved_shortages:
        wh, prod, qty = u
        print("   - " + wh + " still short of " + prod + " by " + str(qty) + " units")
print("=" * 68)
