# Case Study 1: Traffic Flow and Congestion Analysis
roads = ["NH-16 Bypass", "MG Road", "Ring Road East", "Station Link"]
intervals = ["06:00-09:00", "09:00-12:00", "12:00-15:00", "17:00-20:00"]
capacities = [500, 350, 420, 280]

# Nested list: rows = roads, columns = time intervals (vehicle counts)
vehicle_counts = [
    [320, 480, 290, 560],
    [210, 390, 260, 410],
    [250, 340, 220, 460],
    [180, 275, 190, 310]
]

print("=" * 68)
print("          TRAFFIC FLOW AND CONGESTION ANALYSIS REPORT")
print("=" * 68)

# 1. Calculate total vehicles per time interval and identify peak period
interval_totals = []
for c in range(len(intervals)):
    col_sum = 0
    for r in range(len(roads)):
        col_sum = col_sum + vehicle_counts[r][c]
    interval_totals.append(col_sum)

peak_total = interval_totals[0]
peak_index = 0
for c in range(1, len(intervals)):
    if interval_totals[c] > peak_total:
        peak_total = interval_totals[c]
        peak_index = c

print("\n1. Interval Traffic Totals & Volume Pattern:")
for c in range(len(intervals)):
    bar_len = interval_totals[c] // 80
    bar = "#" * bar_len
    tag = "  <-- PEAK PERIOD" if c == peak_index else ""
    print("   " + intervals[c] + " : " + str(interval_totals[c]).rjust(4) + " vehicles | " + bar + tag)

# 2. Classify congestion levels & identify roads exceeding capacity
print("\n2. Road-Wise Congestion Classification:")
exceeded_roads = []

for r in range(len(roads)):
    road_name = roads[r]
    cap = capacities[r]
    road_exceeded = False
    print("\n   Road: " + road_name + " (Capacity Threshold: " + str(cap) + ")")
    for c in range(len(intervals)):
        count = vehicle_counts[r][c]
        ratio = (count / cap) * 100
        if ratio > 100:
            level = "SEVERE (Over Capacity)"
            road_exceeded = True
        elif ratio >= 85:
            level = "HEAVY"
        elif ratio >= 60:
            level = "MODERATE"
        else:
            level = "LOW"
        print("     " + intervals[c] + " -> " + str(count).rjust(3) + " veh (" + str(round(ratio, 1)).rjust(5) + "%) : " + level)
    if road_exceeded:
        exceeded_roads.append(road_name)

print("\n3. Roads Exceeding Capacity Threshold:")
if len(exceeded_roads) == 0:
    print("   None")
else:
    for road in exceeded_roads:
        print("   - " + road)
print("=" * 68)
