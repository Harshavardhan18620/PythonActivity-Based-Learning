# Case Study 9: Tuple-Based Employee Shift Conflict Detection
# Tuple of immutable shift records: (emp_id, emp_name, day, start_hr, end_hr)
shifts = (
    ("E101", "Aarav",  "Mon",  9, 13),
    ("E102", "Bhavna", "Mon",  8, 12),
    ("E101", "Aarav",  "Mon", 12, 16),   # Overlaps with 9-13
    ("E103", "Chetan", "Tue", 10, 14),
    ("E102", "Bhavna", "Mon", 12, 16),   # Back-to-back (no overlap)
    ("E103", "Chetan", "Tue", 13, 17),   # Overlaps with 10-14
    ("E104", "Diya",   "Wed",  9, 17),
    ("E101", "Aarav",  "Tue",  9, 13)
)

print("=" * 68)
print("         EMPLOYEE SHIFT CONFLICT DETECTION AUDIT REPORT")
print("=" * 68)

print("\n1. Scheduled Shift Records (" + str(len(shifts)) + " total):")
for rec in shifts:
    eid, name, day, start_h, end_h = rec
    bar = ("." * (start_h - 8)) + ("#" * (end_h - start_h)) + ("." * (18 - end_h))
    print("   " + eid + " " + name.ljust(7) + " | " + day + " " + str(start_h).rjust(2) + ":00-" + str(end_h).rjust(2) + ":00 | [" + bar + "]")

conflicts = []
conflicting_employees = []

# Pairwise comparison using tuple unpacking
for i in range(len(shifts)):
    id1, name1, day1, s1, e1 = shifts[i]
    for j in range(i + 1, len(shifts)):
        id2, name2, day2, s2, e2 = shifts[j]
        if id1 == id2 and day1 == day2:
            # Intervals [s1, e1) and [s2, e2) overlap iff s1 < e2 and s2 < e1
            if s1 < e2 and s2 < e1:
                ov_start = s1 if s1 > s2 else s2
                ov_end = e1 if e1 < e2 else e2
                conflicts.append((id1, name1, day1, (s1, e1), (s2, e2), ov_end - ov_start))
                if (id1, name1) not in conflicting_employees:
                    conflicting_employees.append((id1, name1))

print("\n2. Detected Overlapping Shift Pairs (" + str(len(conflicts)) + "):")
if len(conflicts) == 0:
    print("   No shift conflicts found.")
else:
    for c in conflicts:
        eid, name, day, span1, span2, ov_hrs = c
        print("   [CONFLICT] " + eid + " (" + name + ") on " + day + ": " + str(span1[0]) + ":00-" + str(span1[1]) + ":00 overlaps " + str(span2[0]) + ":00-" + str(span2[1]) + ":00 (" + str(ov_hrs) + " hr overlap)")

print("\n3. Employees With Conflicting Schedules:")
for emp in conflicting_employees:
    eid, name = emp
    print("   - " + eid + " : " + name)
print("=" * 68)
