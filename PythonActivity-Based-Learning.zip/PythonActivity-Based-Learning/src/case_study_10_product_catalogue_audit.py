# Case Study 10: Tuple-Based Product Catalogue Audit
# Tuple of product tuples: (prod_id, name, unit_price, stock_qty, reorder_lvl)
catalogue = (
    ("P001", "Wireless Mouse",   750.0,  40, 15),
    ("P002", "USB-C Hub",       1450.0,   8, 12),   # Needs replenishment
    ("P003", "Broken Record",   -200.0,  10,  5),   # Invalid negative price
    ("P004", "Mechanical KB",   3200.0,  18, 10),
    ("P005", "HDMI Cable",       350.0,  -4, 20),   # Invalid negative stock
    ("P006", "Webcam 1080p",    2100.0,   5, 10),   # Needs replenishment
    ("P001", "Duplicate Mouse",  750.0,  10,  5),   # Duplicate product ID
    ("",     "Unnamed Item",     500.0,   6,  5)    # Empty product ID
)

seen_ids = []
valid_records = []
invalid_records = []
replenish_list = []
total_inventory_value = 0.0

print("=" * 70)
print("               PRODUCT CATALOGUE AUDIT & VALUATION REPORT")
print("=" * 70)

for item in catalogue:
    pid, name, price, qty, reorder = item
    errors = []

    if pid == "" or name == "":
        errors.append("Missing ID or Name")
    if pid != "" and pid in seen_ids:
        errors.append("Duplicate Product ID")
    if price <= 0:
        errors.append("Non-positive Price")
    if qty < 0:
        errors.append("Negative Stock Qty")
    if reorder < 0:
        errors.append("Negative Reorder Level")

    if len(errors) > 0:
        invalid_records.append((pid, name, "; ".join(errors)))
    else:
        seen_ids.append(pid)
        val = price * qty
        total_inventory_value = total_inventory_value + val
        valid_records.append((pid, name, price, qty, reorder, val))
        if qty <= reorder:
            order_qty = (reorder * 2) - qty
            replenish_list.append((pid, name, qty, reorder, order_qty))

print("\n1. Valid Product Inventory Valuation (" + str(len(valid_records)) + " items):")
print("   ID   | Product Name   |   Price  | Qty | Reorder |    Value")
print("   " + "-" * 60)
for rec in valid_records:
    pid, name, price, qty, reorder, val = rec
    print("   " + pid.ljust(4) + " | " + name.ljust(14) + " | " + str(round(price, 2)).rjust(8) + " | " + str(qty).rjust(3) + " | " + str(reorder).rjust(7) + " | " + str(round(val, 2)).rjust(9))

print("   " + "-" * 60)
print("   Total Valid Inventory Value: Rs. " + str(round(total_inventory_value, 2)))

print("\n2. Invalid Records Detected (" + str(len(invalid_records)) + "):")
for inv in invalid_records:
    pid, name, reason = inv
    pid_disp = pid if pid != "" else "<EMPTY>"
    print("   [INVALID] " + pid_disp.ljust(7) + " | " + name.ljust(15) + " -> " + reason)

print("\n3. Items Requiring Replenishment (" + str(len(replenish_list)) + "):")
for rep in replenish_list:
    pid, name, qty, reorder, order_qty = rep
    bar = "!" * (reorder - qty + 1)
    print("   - " + pid + " " + name.ljust(14) + " (Stock: " + str(qty) + ", Min: " + str(reorder) + ") -> Order " + str(order_qty) + " units " + bar)
print("=" * 70)
